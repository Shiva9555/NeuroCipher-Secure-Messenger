"""
Database models for the Secure Messenger application.
Uses Flask-SQLAlchemy with SQLite for persistence.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import json

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model with encryption keys and authentication data."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    totp_secret = db.Column(db.String(32), nullable=True)
    totp_enabled = db.Column(db.Boolean, default=False)
    public_key = db.Column(db.Text, nullable=True)
    private_key = db.Column(db.Text, nullable=True)  # In production, use HSM/vault
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_active_user = db.Column(db.Boolean, default=True)
    keystroke_samples = db.Column(db.Integer, default=0)
    ml_verified = db.Column(db.Boolean, default=False)

    # Relationships
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id',
                                     backref='sender', lazy='dynamic')
    received_messages = db.relationship('Message', foreign_keys='Message.recipient_id',
                                         backref='recipient', lazy='dynamic')

    def __repr__(self):
        return f'<User {self.username}>'


class Message(db.Model):
    """Encrypted message model."""
    __tablename__ = 'messages'

    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    encrypted_data = db.Column(db.LargeBinary, nullable=False)
    encrypted_key = db.Column(db.LargeBinary, nullable=False)
    nonce = db.Column(db.LargeBinary, nullable=False)
    tag = db.Column(db.LargeBinary, nullable=False)
    is_file = db.Column(db.Boolean, default=False)
    original_filename = db.Column(db.String(256), nullable=True)
    file_size = db.Column(db.Integer, nullable=True)
    encryption_time_ms = db.Column(db.Float, nullable=True)
    algorithm = db.Column(db.String(128), default='NeuroCipher-v1')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_at = db.Column(db.DateTime, nullable=True)
    is_read = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<Message {self.id}: {self.sender_id} -> {self.recipient_id}>'


class SecurityLog(db.Model):
    """Security audit log for tracking authentication events."""
    __tablename__ = 'security_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    event_type = db.Column(db.String(50), nullable=False)  # login, logout, failed_login, etc.
    success = db.Column(db.Boolean, default=True)
    ip_address = db.Column(db.String(45), nullable=True)
    trust_score = db.Column(db.Float, nullable=True)
    factors_used = db.Column(db.Text, nullable=True)  # JSON
    risk_level = db.Column(db.String(20), nullable=True)
    details = db.Column(db.Text, nullable=True)  # JSON for extra info
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<SecurityLog {self.event_type} user={self.user_id}>'
