/**
 * NeuroCipher Secure Messenger - Client-Side JavaScript
 * Handles keystroke dynamics capture and UI interactions
 */

// ---- Keystroke Dynamics Capture ----
class KeystrokeCapture {
    constructor() {
        this.events = [];
        this.active = false;
    }

    startCapture(element) {
        this.events = [];
        this.active = true;

        element.addEventListener('keydown', (e) => {
            if (!this.active) return;
            this.events.push({
                key: e.key.length === 1 ? '*' : e.key,
                press_time: performance.now(),
                release_time: null
            });
        });

        element.addEventListener('keyup', (e) => {
            if (!this.active) return;
            const event = [...this.events].reverse().find(ev => ev.release_time === null);
            if (event) {
                event.release_time = performance.now();
            }
        });
    }

    stopCapture() {
        this.active = false;
        // Ensure all events have release times
        this.events.forEach(ev => {
            if (ev.release_time === null) {
                ev.release_time = ev.press_time + 100;
            }
        });
        return this.events;
    }

    getEvents() {
        return this.events;
    }

    reset() {
        this.events = [];
    }
}

// ---- Flash Message Auto-Dismiss ----
document.addEventListener('DOMContentLoaded', () => {
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(msg => {
        setTimeout(() => {
            msg.style.opacity = '0';
            msg.style.transform = 'translateY(-10px)';
            setTimeout(() => msg.remove(), 300);
        }, 5000);
    });
});

// ---- Smooth page transitions ----
document.addEventListener('DOMContentLoaded', () => {
    document.body.style.opacity = '1';
});

// ---- Utility: Format bytes ----
function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// ---- Utility: Copy to clipboard ----
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // Show subtle feedback
        const tooltip = document.createElement('div');
        tooltip.textContent = 'Copied!';
        tooltip.style.cssText = `
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            padding: 0.5rem 1rem;
            background: rgba(16, 185, 129, 0.9);
            color: white;
            border-radius: 8px;
            font-size: 0.85rem;
            z-index: 1000;
            animation: slideDown 0.3s ease-out;
        `;
        document.body.appendChild(tooltip);
        setTimeout(() => tooltip.remove(), 2000);
    });
}
