"""
NeuroCipher - A Hybrid Encryption Algorithm with ML-Enhanced Security

Architecture:
    1. RSA-2048 for asymmetric key exchange
    2. AES-256-GCM for symmetric data encryption
    3. ML-Generated Dynamic S-Box for additional byte-level substitution
    4. Neural Key Derivation: generates per-message perturbation keys
       from message entropy features using a trained neural network

The ML layer adds a unique, user-specific transformation that makes
the cipher resistant to attacks even if AES keys are compromised,
as the attacker would also need the ML model weights.
"""

import os
import hashlib
import struct
import time
import numpy as np
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes
from sklearn.neural_network import MLPRegressor
import joblib


class NeuroCipher:
    """
    Hybrid encryption combining AES-256-GCM, RSA-2048, and
    ML-based dynamic byte substitution for enhanced security.
    """

    def __init__(self, rsa_key_size=2048, aes_key_size=32):
        self.rsa_key_size = rsa_key_size
        self.aes_key_size = aes_key_size  # 32 bytes = 256 bits
        self.ml_model = None
        self._sbox = None
        self._inv_sbox = None
        self._initialize_ml_model()

    # ------------------------------------------------------------------ #
    #                        RSA Key Management                           #
    # ------------------------------------------------------------------ #

    def generate_rsa_keypair(self):
        """Generate an RSA key pair for asymmetric encryption."""
        key = RSA.generate(self.rsa_key_size)
        private_key = key.export_key()
        public_key = key.publickey().export_key()
        return private_key, public_key

    def _rsa_encrypt(self, data: bytes, public_key_pem: bytes) -> bytes:
        """Encrypt data with RSA public key (for AES key exchange)."""
        pub_key = RSA.import_key(public_key_pem)
        cipher = PKCS1_OAEP.new(pub_key)
        return cipher.encrypt(data)

    def _rsa_decrypt(self, ciphertext: bytes, private_key_pem: bytes) -> bytes:
        """Decrypt data with RSA private key."""
        priv_key = RSA.import_key(private_key_pem)
        cipher = PKCS1_OAEP.new(priv_key)
        return cipher.decrypt(ciphertext)

    # ------------------------------------------------------------------ #
    #           ML-Based Dynamic S-Box & Key Derivation                   #
    # ------------------------------------------------------------------ #

    def _initialize_ml_model(self):
        """
        Initialize the ML model that generates dynamic encryption
        parameters based on message entropy features.
        """
        self.ml_model = MLPRegressor(
            hidden_layer_sizes=(64, 128, 64),
            activation='relu',
            max_iter=500,
            random_state=42,
            warm_start=True
        )
        # Train with initial seed data so the model is ready
        self._train_initial_model()

    def _train_initial_model(self):
        """Pre-train the model with synthetic entropy patterns."""
        np.random.seed(42)
        n_samples = 200
        # Features: [entropy, byte_variance, byte_mean, length_log,
        #            unique_ratio, chi_square_approx, serial_corr, max_freq]
        X = np.random.rand(n_samples, 8)
        # Target: 256 values for S-box generation seed
        y = np.random.rand(n_samples, 256)
        self.ml_model.fit(X, y)

    def _extract_entropy_features(self, data: bytes) -> np.ndarray:
        """
        Extract statistical features from the message to feed the ML model.
        These features capture the entropy profile of the message.
        """
        if len(data) == 0:
            return np.zeros(8)

        byte_array = np.frombuffer(data, dtype=np.uint8).astype(float)

        # 1. Shannon entropy
        _, counts = np.unique(byte_array, return_counts=True)
        probs = counts / len(byte_array)
        entropy = -np.sum(probs * np.log2(probs + 1e-10))
        entropy_norm = entropy / 8.0  # Normalize to [0, 1]

        # 2. Byte variance (normalized)
        byte_var = np.var(byte_array) / (127.5 ** 2)

        # 3. Byte mean (normalized)
        byte_mean = np.mean(byte_array) / 255.0

        # 4. Log of data length (normalized)
        length_log = np.log2(len(data) + 1) / 30.0  # max ~1GB

        # 5. Unique byte ratio
        unique_ratio = len(np.unique(byte_array)) / 256.0

        # 6. Approximate chi-square statistic (normalized)
        expected = len(byte_array) / 256.0
        full_counts = np.zeros(256)
        vals, cnts = np.unique(byte_array.astype(int), return_counts=True)
        full_counts[vals] = cnts
        chi_sq = np.sum((full_counts - expected) ** 2 / (expected + 1e-10))
        chi_sq_norm = min(chi_sq / (256 * len(byte_array)), 1.0)

        # 7. Serial correlation
        if len(byte_array) > 1:
            serial_corr = np.abs(np.corrcoef(byte_array[:-1], byte_array[1:])[0, 1])
            if np.isnan(serial_corr):
                serial_corr = 0.0
        else:
            serial_corr = 0.0

        # 8. Max byte frequency
        max_freq = np.max(counts) / len(byte_array)

        return np.array([
            entropy_norm, byte_var, byte_mean, length_log,
            unique_ratio, chi_sq_norm, serial_corr, max_freq
        ])

    def _generate_dynamic_sbox(self, data: bytes, seed_key: bytes) -> tuple:
        """
        Use the ML model + a seed key to generate a unique 256-byte
        S-box (substitution box) for this specific message.
        """
        features = self._extract_entropy_features(data).reshape(1, -1)
        ml_output = self.ml_model.predict(features)[0]

        # Combine ML output with the seed key hash for determinism
        key_hash = hashlib.sha256(seed_key).digest()
        key_values = np.frombuffer(key_hash, dtype=np.uint8).astype(float) / 255.0

        # Blend ML prediction with key-derived values
        # The ML model personalizes the S-box; the key ensures security
        combined = np.zeros(256)
        for i in range(256):
            combined[i] = (ml_output[i] + key_values[i % len(key_values)]) % 1.0

        # Generate permutation from combined values (Fisher-Yates-like)
        indices = np.argsort(combined)
        sbox = np.zeros(256, dtype=np.uint8)
        inv_sbox = np.zeros(256, dtype=np.uint8)
        for i in range(256):
            sbox[i] = indices[i]
            inv_sbox[indices[i]] = i

        return bytes(sbox), bytes(inv_sbox)

    # ------------------------------------------------------------------ #
    #              Custom Byte-Level Transformation Layer                  #
    # ------------------------------------------------------------------ #

    def _apply_sbox_transform(self, data: bytes, sbox: bytes) -> bytes:
        """Apply S-box substitution to each byte of data."""
        return bytes(sbox[b] for b in data)

    def _apply_xor_layer(self, data: bytes, key: bytes) -> bytes:
        """Apply repeating XOR with the key for additional diffusion."""
        key_len = len(key)
        return bytes(data[i] ^ key[i % key_len] for i in range(len(data)))

    def _neural_transform(self, data: bytes, seed_key: bytes, encrypt=True) -> bytes:
        """
        Apply the ML-enhanced transformation layer.
        This is applied BEFORE AES encryption and AFTER AES decryption.
        The S-box is derived deterministically from the seed_key alone
        (not the data) so that encrypt and decrypt produce the same S-box.
        """
        # Use a deterministic synthetic feature vector derived from the seed_key
        # This ensures the same S-box is generated for both encrypt and decrypt
        seed_features = hashlib.sha256(seed_key + b'sbox_features').digest()
        synthetic_data = seed_features * 4  # 128 bytes of deterministic data
        sbox, inv_sbox = self._generate_dynamic_sbox(synthetic_data, seed_key)

        # Derive a XOR key from seed + ML model hash
        xor_key = hashlib.sha512(seed_key + b'neural_xor_layer').digest()

        if encrypt:
            # Forward: XOR -> S-box substitution
            data = self._apply_xor_layer(data, xor_key)
            data = self._apply_sbox_transform(data, sbox)
        else:
            # Inverse: Inverse S-box -> XOR
            data = self._apply_sbox_transform(data, inv_sbox)
            data = self._apply_xor_layer(data, xor_key)

        return data

    # ------------------------------------------------------------------ #
    #                     Core Encrypt / Decrypt                          #
    # ------------------------------------------------------------------ #

    def encrypt_message(self, plaintext: str, recipient_public_key: bytes) -> dict:
        """
        Encrypt a message using the NeuroCipher hybrid algorithm.

        Steps:
            1. Generate a random AES-256 session key
            2. Generate a neural seed key for ML transformations
            3. Apply ML-enhanced neural transform to plaintext bytes
            4. Encrypt the transformed data with AES-256-GCM
            5. Encrypt the AES key + neural seed with RSA
            6. Return the encrypted package

        Returns:
            dict with encrypted_data, encrypted_key, nonce, tag, timestamp
        """
        start_time = time.time()

        plaintext_bytes = plaintext.encode('utf-8')

        # Generate session keys
        aes_key = get_random_bytes(self.aes_key_size)
        neural_seed = get_random_bytes(32)  # Seed for ML S-box generation

        # Step 1: Apply neural transformation (ML-enhanced layer)
        transformed = self._neural_transform(plaintext_bytes, neural_seed, encrypt=True)

        # Step 2: AES-256-GCM encryption
        cipher = AES.new(aes_key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(transformed)

        # Step 3: RSA encrypt the combined key material
        combined_key = aes_key + neural_seed  # 64 bytes total
        encrypted_key = self._rsa_encrypt(combined_key, recipient_public_key)

        elapsed = time.time() - start_time

        return {
            'encrypted_data': ciphertext,
            'encrypted_key': encrypted_key,
            'nonce': cipher.nonce,
            'tag': tag,
            'timestamp': time.time(),
            'encryption_time_ms': round(elapsed * 1000, 2),
            'algorithm': 'NeuroCipher-v1 (AES-256-GCM + RSA-2048 + ML-SBox)'
        }

    def decrypt_message(self, encrypted_package: dict,
                        recipient_private_key: bytes) -> str:
        """
        Decrypt a message encrypted with NeuroCipher.

        Steps:
            1. RSA decrypt to recover AES key + neural seed
            2. AES-256-GCM decrypt the ciphertext
            3. Apply inverse neural transform
            4. Return the original plaintext
        """
        start_time = time.time()

        # Step 1: RSA decrypt key material
        combined_key = self._rsa_decrypt(
            encrypted_package['encrypted_key'],
            recipient_private_key
        )
        aes_key = combined_key[:self.aes_key_size]
        neural_seed = combined_key[self.aes_key_size:]

        # Step 2: AES-GCM decrypt
        cipher = AES.new(aes_key, AES.MODE_GCM,
                         nonce=encrypted_package['nonce'])
        transformed = cipher.decrypt_and_verify(
            encrypted_package['encrypted_data'],
            encrypted_package['tag']
        )

        # Step 3: Inverse neural transform
        plaintext_bytes = self._neural_transform(
            transformed, neural_seed, encrypt=False
        )

        elapsed = time.time() - start_time
        return plaintext_bytes.decode('utf-8')

    def encrypt_file(self, filepath: str, recipient_public_key: bytes) -> dict:
        """Encrypt a file using NeuroCipher."""
        with open(filepath, 'rb') as f:
            file_data = f.read()

        start_time = time.time()
        aes_key = get_random_bytes(self.aes_key_size)
        neural_seed = get_random_bytes(32)

        # Neural transform on file bytes
        transformed = self._neural_transform(file_data, neural_seed, encrypt=True)

        # AES-GCM encrypt
        cipher = AES.new(aes_key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(transformed)

        # RSA encrypt keys
        combined_key = aes_key + neural_seed
        encrypted_key = self._rsa_encrypt(combined_key, recipient_public_key)

        elapsed = time.time() - start_time

        return {
            'encrypted_data': ciphertext,
            'encrypted_key': encrypted_key,
            'nonce': cipher.nonce,
            'tag': tag,
            'original_filename': os.path.basename(filepath),
            'original_size': len(file_data),
            'encrypted_size': len(ciphertext),
            'timestamp': time.time(),
            'encryption_time_ms': round(elapsed * 1000, 2),
            'algorithm': 'NeuroCipher-v1 (AES-256-GCM + RSA-2048 + ML-SBox)'
        }

    def decrypt_file(self, encrypted_package: dict,
                     recipient_private_key: bytes,
                     output_path: str) -> str:
        """Decrypt a file encrypted with NeuroCipher."""
        combined_key = self._rsa_decrypt(
            encrypted_package['encrypted_key'],
            recipient_private_key
        )
        aes_key = combined_key[:self.aes_key_size]
        neural_seed = combined_key[self.aes_key_size:]

        cipher = AES.new(aes_key, AES.MODE_GCM,
                         nonce=encrypted_package['nonce'])
        transformed = cipher.decrypt_and_verify(
            encrypted_package['encrypted_data'],
            encrypted_package['tag']
        )

        file_data = self._neural_transform(
            transformed, neural_seed, encrypt=False
        )

        with open(output_path, 'wb') as f:
            f.write(file_data)

        return output_path

    def save_ml_model(self, path: str):
        """Save the ML model for persistence."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump(self.ml_model, path)

    def load_ml_model(self, path: str):
        """Load a previously saved ML model."""
        if os.path.exists(path):
            self.ml_model = joblib.load(path)

    def train_on_user_data(self, user_messages: list):
        """
        Fine-tune the ML model on user-specific message patterns.
        This makes the S-box generation unique to each user,
        adding a personalized security layer.
        """
        if len(user_messages) < 5:
            return False

        X = []
        y = []
        for msg in user_messages:
            if isinstance(msg, str):
                msg = msg.encode('utf-8')
            features = self._extract_entropy_features(msg)
            X.append(features)
            # Target: deterministic but unique S-box seed from message hash
            msg_hash = hashlib.sha256(msg).digest()
            target = np.frombuffer(
                hashlib.sha256(msg_hash).digest() * 8, dtype=np.uint8
            )[:256].astype(float) / 255.0
            y.append(target)

        X = np.array(X)
        y = np.array(y)
        self.ml_model.fit(X, y)
        return True
