"""
Encryption Benchmark Module

Compares NeuroCipher against standard AES-256-GCM and RSA-only
encryption in terms of speed, throughput, and security metrics.
"""

import time
import os
import json
import numpy as np
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes
from .neuro_cipher import NeuroCipher


class EncryptionBenchmark:
    """Benchmarks NeuroCipher against standard algorithms."""

    def __init__(self):
        self.cipher = NeuroCipher()
        self.results = {}

    def _benchmark_aes_only(self, data: bytes) -> dict:
        """Benchmark plain AES-256-GCM encryption."""
        key = get_random_bytes(32)

        # Encryption
        start = time.time()
        cipher = AES.new(key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        enc_time = time.time() - start

        # Decryption
        start = time.time()
        dec_cipher = AES.new(key, AES.MODE_GCM, nonce=cipher.nonce)
        plaintext = dec_cipher.decrypt_and_verify(ciphertext, tag)
        dec_time = time.time() - start

        return {
            'algorithm': 'AES-256-GCM',
            'encryption_time_ms': round(enc_time * 1000, 3),
            'decryption_time_ms': round(dec_time * 1000, 3),
            'total_time_ms': round((enc_time + dec_time) * 1000, 3),
            'data_size_bytes': len(data),
            'ciphertext_size_bytes': len(ciphertext),
            'overhead_bytes': len(ciphertext) - len(data) + len(tag) + len(cipher.nonce),
            'integrity_verified': plaintext == data
        }

    def _benchmark_neuro_cipher(self, data: str, pub_key: bytes,
                                 priv_key: bytes) -> dict:
        """Benchmark NeuroCipher encryption."""
        # Encryption
        start = time.time()
        encrypted = self.cipher.encrypt_message(data, pub_key)
        enc_time = time.time() - start

        # Decryption
        start = time.time()
        decrypted = self.cipher.decrypt_message(encrypted, priv_key)
        dec_time = time.time() - start

        data_bytes = data.encode('utf-8')
        return {
            'algorithm': 'NeuroCipher-v1',
            'encryption_time_ms': round(enc_time * 1000, 3),
            'decryption_time_ms': round(dec_time * 1000, 3),
            'total_time_ms': round((enc_time + dec_time) * 1000, 3),
            'data_size_bytes': len(data_bytes),
            'ciphertext_size_bytes': len(encrypted['encrypted_data']),
            'overhead_bytes': (len(encrypted['encrypted_data']) - len(data_bytes)
                             + len(encrypted['tag']) + len(encrypted['nonce'])
                             + len(encrypted['encrypted_key'])),
            'integrity_verified': decrypted == data
        }

    def run_benchmark(self, test_sizes=None) -> dict:
        """
        Run comprehensive benchmarks comparing algorithms.

        Args:
            test_sizes: List of data sizes in bytes to test.
                       Defaults to [100, 1000, 10000, 100000]

        Returns:
            dict with benchmark results for each algorithm and size.
        """
        if test_sizes is None:
            test_sizes = [100, 1_000, 10_000, 100_000]

        # Generate RSA keys once
        priv_key, pub_key = self.cipher.generate_rsa_keypair()

        results = {'tests': [], 'summary': {}}

        for size in test_sizes:
            # Generate test data
            test_data = os.urandom(size)
            test_text = ''.join(chr(b % 94 + 32) for b in test_data)

            # AES-only benchmark
            aes_result = self._benchmark_aes_only(test_data)
            aes_result['test_size_label'] = f"{size} bytes"

            # NeuroCipher benchmark
            neuro_result = self._benchmark_neuro_cipher(
                test_text[:size], pub_key, priv_key
            )
            neuro_result['test_size_label'] = f"{size} bytes"

            results['tests'].append({
                'size': size,
                'aes_gcm': aes_result,
                'neuro_cipher': neuro_result
            })

        # Summary
        neuro_times = [t['neuro_cipher']['total_time_ms'] for t in results['tests']]
        aes_times = [t['aes_gcm']['total_time_ms'] for t in results['tests']]

        results['summary'] = {
            'neuro_cipher_avg_ms': round(np.mean(neuro_times), 3),
            'aes_gcm_avg_ms': round(np.mean(aes_times), 3),
            'overhead_factor': round(np.mean(neuro_times) / max(np.mean(aes_times), 0.001), 2),
            'all_integrity_checks_passed': all(
                t['neuro_cipher']['integrity_verified'] and t['aes_gcm']['integrity_verified']
                for t in results['tests']
            ),
            'security_layers': {
                'aes_gcm': ['AES-256-GCM symmetric encryption'],
                'neuro_cipher': [
                    'AES-256-GCM symmetric encryption',
                    'RSA-2048 key exchange',
                    'ML-generated dynamic S-Box substitution',
                    'Neural XOR diffusion layer',
                    'Per-message unique transformation'
                ]
            }
        }

        self.results = results
        return results

    def get_results_json(self) -> str:
        """Return benchmark results as JSON string."""
        return json.dumps(self.results, indent=2, default=str)

    def print_report(self):
        """Print a formatted benchmark report."""
        if not self.results:
            self.run_benchmark()

        print("\n" + "=" * 70)
        print("        NeuroCipher Encryption Benchmark Report")
        print("=" * 70)

        for test in self.results['tests']:
            size = test['size']
            aes = test['aes_gcm']
            neuro = test['neuro_cipher']

            print(f"\n--- Data Size: {size:,} bytes ---")
            print(f"  {'Metric':<30} {'AES-256-GCM':>15} {'NeuroCipher':>15}")
            print(f"  {'-' * 60}")
            print(f"  {'Encryption (ms)':<30} {aes['encryption_time_ms']:>15.3f} {neuro['encryption_time_ms']:>15.3f}")
            print(f"  {'Decryption (ms)':<30} {aes['decryption_time_ms']:>15.3f} {neuro['decryption_time_ms']:>15.3f}")
            print(f"  {'Total (ms)':<30} {aes['total_time_ms']:>15.3f} {neuro['total_time_ms']:>15.3f}")
            print(f"  {'Integrity Verified':<30} {str(aes['integrity_verified']):>15} {str(neuro['integrity_verified']):>15}")

        summary = self.results['summary']
        print(f"\n{'=' * 70}")
        print(f"  Summary:")
        print(f"    AES-256-GCM Average:    {summary['aes_gcm_avg_ms']:.3f} ms")
        print(f"    NeuroCipher Average:     {summary['neuro_cipher_avg_ms']:.3f} ms")
        print(f"    Overhead Factor:         {summary['overhead_factor']}x")
        print(f"    All Integrity Passed:    {summary['all_integrity_checks_passed']}")
        print(f"\n  NeuroCipher Security Layers:")
        for layer in summary['security_layers']['neuro_cipher']:
            print(f"    [OK] {layer}")
        print("=" * 70)
