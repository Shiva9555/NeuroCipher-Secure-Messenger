"""
ML-Based Keystroke Dynamics Verifier

Uses machine learning to verify user identity based on typing patterns.
Captures timing features from keystrokes and builds a user-specific
behavioral profile using:
    - Random Forest Classifier for user identification
    - Isolation Forest for anomaly detection (impostor detection)

Features extracted from typing patterns:
    - Key hold duration (dwell time)
    - Inter-key delay (flight time)
    - Key press pressure patterns (simulated)
    - Typing speed (WPM)
    - Statistical features (mean, std, skew of timings)
"""

import numpy as np
import os
import json
import hashlib
from datetime import datetime
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score
import joblib


class KeystrokeDynamicsVerifier:
    """
    ML-based behavioral biometric authentication using keystroke dynamics.
    """

    FEATURE_NAMES = [
        'avg_dwell_time',         # Average key hold duration
        'std_dwell_time',         # Std deviation of dwell
        'avg_flight_time',        # Average inter-key delay
        'std_flight_time',        # Std deviation of flight
        'typing_speed_cps',       # Characters per second
        'dwell_skewness',         # Skewness of dwell distribution
        'flight_skewness',        # Skewness of flight distribution
        'dwell_kurtosis',         # Kurtosis of dwell distribution
        'flight_kurtosis',        # Kurtosis of flight distribution
        'avg_digraph_time',       # Average time for character pairs
        'rhythm_regularity',      # How regular is the typing rhythm
        'pause_frequency',        # Frequency of pauses (>500ms gaps)
        'burst_rate',             # Ratio of fast consecutive keys
        'total_typing_duration',  # Total time for the sample
    ]

    def __init__(self, model_dir='ml_models'):
        self.model_dir = model_dir
        self.classifier = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.anomaly_detector = IsolationForest(
            contamination=0.1,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.user_profiles = {}  # user_id -> list of feature vectors
        self.is_trained = False
        os.makedirs(model_dir, exist_ok=True)

    # ------------------------------------------------------------------ #
    #                      Feature Extraction                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def extract_features(keystroke_events: list) -> np.ndarray:
        """
        Extract 14 timing features from a sequence of keystroke events.

        Args:
            keystroke_events: list of dicts with keys:
                - 'key': the key pressed
                - 'press_time': timestamp of key press (ms)
                - 'release_time': timestamp of key release (ms)

        Returns:
            numpy array of 14 features
        """
        if len(keystroke_events) < 3:
            return np.zeros(14)

        # Calculate dwell times (key hold duration)
        dwell_times = []
        for event in keystroke_events:
            dwell = event.get('release_time', event['press_time'] + 100) - event['press_time']
            dwell_times.append(max(dwell, 1))  # Minimum 1ms

        # Calculate flight times (inter-key delay)
        flight_times = []
        for i in range(1, len(keystroke_events)):
            flight = keystroke_events[i]['press_time'] - keystroke_events[i-1].get(
                'release_time', keystroke_events[i-1]['press_time'] + 100
            )
            flight_times.append(max(flight, 0))

        dwell_arr = np.array(dwell_times, dtype=float)
        flight_arr = np.array(flight_times, dtype=float) if flight_times else np.array([0.0])

        # Feature extraction
        features = []

        # 1-2: Dwell time statistics
        features.append(np.mean(dwell_arr))
        features.append(np.std(dwell_arr))

        # 3-4: Flight time statistics
        features.append(np.mean(flight_arr))
        features.append(np.std(flight_arr))

        # 5: Typing speed (characters per second)
        total_time = (keystroke_events[-1].get('release_time',
                      keystroke_events[-1]['press_time'] + 100)
                      - keystroke_events[0]['press_time'])
        cps = len(keystroke_events) / max(total_time / 1000.0, 0.1)
        features.append(cps)

        # 6-7: Skewness
        def safe_skewness(arr):
            if len(arr) < 3 or np.std(arr) == 0:
                return 0.0
            return float(np.mean(((arr - np.mean(arr)) / max(np.std(arr), 1e-10)) ** 3))

        features.append(safe_skewness(dwell_arr))
        features.append(safe_skewness(flight_arr))

        # 8-9: Kurtosis
        def safe_kurtosis(arr):
            if len(arr) < 4 or np.std(arr) == 0:
                return 0.0
            return float(np.mean(((arr - np.mean(arr)) / max(np.std(arr), 1e-10)) ** 4) - 3)

        features.append(safe_kurtosis(dwell_arr))
        features.append(safe_kurtosis(flight_arr))

        # 10: Average digraph time
        if len(keystroke_events) >= 2:
            digraph_times = [
                keystroke_events[i+1].get('release_time',
                    keystroke_events[i+1]['press_time'] + 100)
                - keystroke_events[i]['press_time']
                for i in range(len(keystroke_events) - 1)
            ]
            features.append(np.mean(digraph_times))
        else:
            features.append(0.0)

        # 11: Rhythm regularity (inverse of coefficient of variation)
        if len(flight_arr) > 1 and np.mean(flight_arr) > 0:
            cv = np.std(flight_arr) / np.mean(flight_arr)
            features.append(1.0 / (1.0 + cv))
        else:
            features.append(0.5)

        # 12: Pause frequency (gaps > 500ms)
        pauses = sum(1 for f in flight_arr if f > 500)
        features.append(pauses / max(len(flight_arr), 1))

        # 13: Burst rate (ratio of very fast consecutive keys, <80ms)
        bursts = sum(1 for f in flight_arr if f < 80)
        features.append(bursts / max(len(flight_arr), 1))

        # 14: Total typing duration (seconds)
        features.append(total_time / 1000.0)

        return np.array(features, dtype=float)

    # ------------------------------------------------------------------ #
    #                    Enrollment & Training                            #
    # ------------------------------------------------------------------ #

    def enroll_sample(self, user_id: str, keystroke_events: list) -> dict:
        """
        Enroll a keystroke sample for a user.
        Multiple samples are needed to build an accurate profile.
        """
        features = self.extract_features(keystroke_events)

        if user_id not in self.user_profiles:
            self.user_profiles[user_id] = []

        self.user_profiles[user_id].append(features.tolist())

        sample_count = len(self.user_profiles[user_id])
        can_train = sample_count >= 5

        return {
            'user_id': user_id,
            'sample_number': sample_count,
            'samples_needed': max(0, 5 - sample_count),
            'can_train': can_train,
            'features_extracted': len(features),
            'message': f'Sample {sample_count} enrolled. '
                      f'{"Ready for training!" if can_train else f"Need {5 - sample_count} more samples."}'
        }

    def train_model(self) -> dict:
        """
        Train the classifier and anomaly detector on enrolled user profiles.
        """
        if not self.user_profiles:
            return {'success': False, 'message': 'No user profiles to train on'}

        X = []
        y = []
        user_ids = []

        for user_id, samples in self.user_profiles.items():
            if len(samples) >= 3:
                for sample in samples:
                    X.append(sample)
                    y.append(user_id)
                user_ids.append(user_id)

        if len(X) < 5 or len(set(y)) < 1:
            return {'success': False, 'message': 'Not enough data to train'}

        X = np.array(X)
        y = np.array(y)

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Train classifier
        self.classifier.fit(X_scaled, y)

        # Train anomaly detector on all legitimate user data
        self.anomaly_detector.fit(X_scaled)

        self.is_trained = True

        # Cross-validation score if enough data
        cv_score = 0.0
        if len(X) >= 10 and len(set(y)) >= 2:
            try:
                scores = cross_val_score(self.classifier, X_scaled, y, cv=min(5, len(X)))
                cv_score = float(np.mean(scores))
            except Exception:
                cv_score = 0.0

        return {
            'success': True,
            'users_trained': len(user_ids),
            'total_samples': len(X),
            'cv_accuracy': round(cv_score, 3),
            'feature_importances': dict(zip(
                self.FEATURE_NAMES,
                [round(f, 4) for f in self.classifier.feature_importances_]
            ))
        }

    # ------------------------------------------------------------------ #
    #                        Verification                                 #
    # ------------------------------------------------------------------ #

    def verify_user(self, user_id: str, keystroke_events: list) -> dict:
        """
        Verify if the typing pattern matches the claimed user identity.

        Returns:
            dict with:
                - verified: bool
                - confidence: float (0-1)
                - anomaly_score: float
                - predicted_user: str
                - details: dict
        """
        features = self.extract_features(keystroke_events)

        if not self.is_trained:
            # If model is not trained, use statistical comparison
            return self._statistical_verify(user_id, features)

        features_scaled = self.scaler.transform(features.reshape(1, -1))

        # Classifier prediction
        predicted_user = self.classifier.predict(features_scaled)[0]
        probabilities = self.classifier.predict_proba(features_scaled)[0]
        class_labels = self.classifier.classes_

        # Get confidence for claimed user
        if user_id in class_labels:
            user_idx = list(class_labels).index(user_id)
            user_confidence = float(probabilities[user_idx])
        else:
            user_confidence = 0.0

        # Anomaly detection (-1 = anomaly, 1 = normal)
        anomaly_pred = self.anomaly_detector.predict(features_scaled)[0]
        anomaly_score = float(self.anomaly_detector.score_samples(features_scaled)[0])

        # Normalize anomaly score to 0-1 (higher = more normal)
        anomaly_normalized = max(0, min(1, (anomaly_score + 0.5)))

        # Combined verification score
        combined_score = 0.6 * user_confidence + 0.4 * anomaly_normalized
        verified = (predicted_user == user_id and
                   combined_score >= 0.5 and
                   anomaly_pred == 1)

        return {
            'verified': verified,
            'confidence': round(combined_score, 3),
            'user_confidence': round(user_confidence, 3),
            'anomaly_score': round(anomaly_normalized, 3),
            'is_anomaly': anomaly_pred == -1,
            'predicted_user': predicted_user,
            'claimed_user': user_id,
            'identity_match': predicted_user == user_id,
            'features': dict(zip(self.FEATURE_NAMES,
                                [round(f, 4) for f in features]))
        }

    def _statistical_verify(self, user_id: str, features: np.ndarray) -> dict:
        """
        Fallback verification using statistical comparison
        when the ML model hasn't been trained yet.
        """
        if user_id not in self.user_profiles or len(self.user_profiles[user_id]) < 2:
            return {
                'verified': True,  # First-time user, allow through
                'confidence': 0.5,
                'user_confidence': 0.5,
                'anomaly_score': 0.5,
                'is_anomaly': False,
                'predicted_user': user_id,
                'claimed_user': user_id,
                'identity_match': True,
                'message': 'Insufficient data for ML verification. Using baseline acceptance.',
                'features': dict(zip(self.FEATURE_NAMES,
                                    [round(f, 4) for f in features]))
            }

        # Compare against stored profiles using Euclidean distance
        stored = np.array(self.user_profiles[user_id])
        mean_profile = np.mean(stored, axis=0)
        std_profile = np.std(stored, axis=0) + 1e-10

        # Z-score distance
        z_scores = np.abs((features - mean_profile) / std_profile)
        avg_z = np.mean(z_scores)

        # Convert to confidence (lower z-score = higher confidence)
        confidence = max(0, 1 - avg_z / 5.0)

        return {
            'verified': confidence >= 0.4,
            'confidence': round(confidence, 3),
            'user_confidence': round(confidence, 3),
            'anomaly_score': round(confidence, 3),
            'is_anomaly': confidence < 0.3,
            'predicted_user': user_id,
            'claimed_user': user_id,
            'identity_match': True,
            'message': 'Statistical verification (ML model not yet trained)',
            'features': dict(zip(self.FEATURE_NAMES,
                                [round(f, 4) for f in features]))
        }

    # ------------------------------------------------------------------ #
    #                       Persistence                                   #
    # ------------------------------------------------------------------ #

    def save_models(self, path=None):
        """Save all ML models and user profiles."""
        path = path or self.model_dir
        os.makedirs(path, exist_ok=True)

        if self.is_trained:
            joblib.dump(self.classifier, os.path.join(path, 'keystroke_classifier.pkl'))
            joblib.dump(self.anomaly_detector, os.path.join(path, 'anomaly_detector.pkl'))
            joblib.dump(self.scaler, os.path.join(path, 'scaler.pkl'))

        with open(os.path.join(path, 'user_profiles.json'), 'w') as f:
            json.dump(self.user_profiles, f)

    def load_models(self, path=None):
        """Load ML models and user profiles."""
        path = path or self.model_dir

        try:
            clf_path = os.path.join(path, 'keystroke_classifier.pkl')
            if os.path.exists(clf_path):
                self.classifier = joblib.load(clf_path)
                self.anomaly_detector = joblib.load(
                    os.path.join(path, 'anomaly_detector.pkl'))
                self.scaler = joblib.load(os.path.join(path, 'scaler.pkl'))
                self.is_trained = True

            profiles_path = os.path.join(path, 'user_profiles.json')
            if os.path.exists(profiles_path):
                with open(profiles_path, 'r') as f:
                    self.user_profiles = json.load(f)
        except Exception as e:
            print(f"Warning: Could not load ML models: {e}")

    # ------------------------------------------------------------------ #
    #                    Demo / Simulation                                #
    # ------------------------------------------------------------------ #

    @staticmethod
    def simulate_keystroke_events(text: str, user_style: str = 'normal') -> list:
        """
        Simulate keystroke events for demo/testing purposes.
        Different styles mimic different typing behaviors.
        """
        np.random.seed(hash(user_style) % (2**31))

        styles = {
            'fast': {'dwell_mean': 60, 'dwell_std': 15,
                    'flight_mean': 50, 'flight_std': 20},
            'normal': {'dwell_mean': 100, 'dwell_std': 30,
                      'flight_mean': 120, 'flight_std': 40},
            'slow': {'dwell_mean': 180, 'dwell_std': 50,
                    'flight_mean': 200, 'flight_std': 60},
            'hunt_peck': {'dwell_mean': 150, 'dwell_std': 80,
                         'flight_mean': 350, 'flight_std': 150},
            'impostor': {'dwell_mean': 130, 'dwell_std': 70,
                        'flight_mean': 180, 'flight_std': 90},
        }

        style = styles.get(user_style, styles['normal'])
        events = []
        current_time = 0

        for char in text:
            dwell = max(20, np.random.normal(style['dwell_mean'], style['dwell_std']))
            if events:
                flight = max(10, np.random.normal(style['flight_mean'], style['flight_std']))
                current_time += flight

            press_time = current_time
            release_time = current_time + dwell
            current_time = release_time

            events.append({
                'key': char,
                'press_time': round(press_time, 1),
                'release_time': round(release_time, 1)
            })

        return events
