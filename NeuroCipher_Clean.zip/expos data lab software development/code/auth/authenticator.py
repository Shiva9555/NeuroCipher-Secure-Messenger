"""
Multi-Factor Authenticator

Implements a layered authentication system:
    1. Password Authentication (bcrypt hashing)
    2. TOTP-Based OTP (Time-Based One-Time Password)
    3. ML-Based Behavioral Verification (Keystroke Dynamics)
    4. Risk Scoring & Anomaly Detection

Each layer adds verification confidence. The system combines
all factors into a composite trust score.
"""

import bcrypt
import pyotp
import qrcode
import io
import base64
import time
import json
import hashlib
from datetime import datetime


class Authenticator:
    """
    Multi-factor authentication system with password hashing,
    TOTP, and ML-based behavioral verification.
    """

    def __init__(self):
        self.login_history = {}  # user_id -> list of login records

    # ------------------------------------------------------------------ #
    #                    Password Authentication                          #
    # ------------------------------------------------------------------ #

    @staticmethod
    def hash_password(password: str) -> str:
        """
        Hash a password using bcrypt with automatic salt generation.
        bcrypt is resistant to rainbow table and brute-force attacks.
        """
        salt = bcrypt.gensalt(rounds=12)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')

    @staticmethod
    def verify_password(password: str, hashed: str) -> bool:
        """Verify a password against its bcrypt hash."""
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                hashed.encode('utf-8')
            )
        except Exception:
            return False

    @staticmethod
    def check_password_strength(password: str) -> dict:
        """
        Evaluate password strength and return a detailed report.
        """
        checks = {
            'min_length': len(password) >= 8,
            'has_uppercase': any(c.isupper() for c in password),
            'has_lowercase': any(c.islower() for c in password),
            'has_digit': any(c.isdigit() for c in password),
            'has_special': any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password),
            'no_common_patterns': not any(
                p in password.lower()
                for p in ['password', '123456', 'qwerty', 'admin', 'letmein']
            )
        }

        score = sum(checks.values())
        strength = 'weak' if score <= 2 else 'fair' if score <= 4 else 'strong' if score <= 5 else 'very_strong'

        return {
            'score': score,
            'max_score': 6,
            'strength': strength,
            'checks': checks,
            'percentage': round(score / 6 * 100)
        }

    # ------------------------------------------------------------------ #
    #                         TOTP (OTP)                                  #
    # ------------------------------------------------------------------ #

    @staticmethod
    def generate_totp_secret() -> str:
        """Generate a new TOTP secret for a user."""
        return pyotp.random_base32()

    @staticmethod
    def get_totp_uri(secret: str, username: str,
                     issuer: str = 'NeuroCipher Messenger') -> str:
        """Get the OTP provisioning URI for QR code generation."""
        totp = pyotp.TOTP(secret)
        return totp.provisioning_uri(name=username, issuer_name=issuer)

    @staticmethod
    def generate_qr_code(secret: str, username: str) -> str:
        """Generate a QR code as base64 PNG for TOTP setup."""
        uri = Authenticator.get_totp_uri(secret, username)
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color='black', back_color='white')

        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        return base64.b64encode(buffer.read()).decode('utf-8')

    @staticmethod
    def verify_totp(secret: str, token: str) -> bool:
        """Verify a TOTP token (allows 1 period of clock drift)."""
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=1)

    @staticmethod
    def get_current_totp(secret: str) -> str:
        """Get the current TOTP token (for testing/demo)."""
        totp = pyotp.TOTP(secret)
        return totp.now()

    # ------------------------------------------------------------------ #
    #                     Risk Scoring & Login Tracking                   #
    # ------------------------------------------------------------------ #

    def record_login_attempt(self, user_id: str, success: bool,
                             ip_address: str = 'unknown',
                             keystroke_score: float = 0.0):
        """Record a login attempt for security analysis."""
        if user_id not in self.login_history:
            self.login_history[user_id] = []

        self.login_history[user_id].append({
            'timestamp': datetime.utcnow().isoformat(),
            'success': success,
            'ip_address': ip_address,
            'keystroke_score': keystroke_score
        })

        # Keep only last 100 attempts
        if len(self.login_history[user_id]) > 100:
            self.login_history[user_id] = self.login_history[user_id][-100:]

    def calculate_risk_score(self, user_id: str, ip_address: str = 'unknown') -> dict:
        """
        Calculate a risk score for a login attempt based on:
        - Recent failed attempts
        - IP address changes
        - Time patterns
        """
        history = self.login_history.get(user_id, [])

        if not history:
            return {'risk_score': 0.0, 'risk_level': 'low', 'factors': []}

        factors = []
        risk = 0.0

        # Check recent failures (last 10 attempts)
        recent = history[-10:]
        failures = sum(1 for h in recent if not h['success'])
        if failures >= 5:
            risk += 0.4
            factors.append(f'{failures}/10 recent login failures')
        elif failures >= 3:
            risk += 0.2
            factors.append(f'{failures}/10 recent login failures')

        # Check for new IP
        known_ips = set(h['ip_address'] for h in history if h['success'])
        if ip_address not in known_ips and known_ips:
            risk += 0.2
            factors.append('Login from new IP address')

        # Check for rapid attempts
        if len(recent) >= 3:
            try:
                times = [datetime.fromisoformat(h['timestamp']) for h in recent[-3:]]
                if (times[-1] - times[0]).total_seconds() < 60:
                    risk += 0.3
                    factors.append('Rapid login attempts detected')
            except Exception:
                pass

        risk = min(risk, 1.0)
        level = 'low' if risk < 0.3 else 'medium' if risk < 0.6 else 'high'

        return {
            'risk_score': round(risk, 2),
            'risk_level': level,
            'factors': factors,
            'recommendation': 'block' if risk >= 0.8 else 'challenge' if risk >= 0.5 else 'allow'
        }

    # ------------------------------------------------------------------ #
    #                  Composite Authentication Score                     #
    # ------------------------------------------------------------------ #

    def authenticate(self, password: str, password_hash: str,
                     totp_token: str = None, totp_secret: str = None,
                     keystroke_score: float = None,
                     user_id: str = None, ip_address: str = 'unknown') -> dict:
        """
        Perform multi-factor authentication and return a composite result.

        Returns:
            dict with:
                - authenticated: bool
                - trust_score: float (0-1)
                - factors_passed: list
                - factors_failed: list
                - risk_assessment: dict
        """
        factors_passed = []
        factors_failed = []
        trust_score = 0.0

        # Factor 1: Password (weight: 0.4)
        password_ok = self.verify_password(password, password_hash)
        if password_ok:
            factors_passed.append('password')
            trust_score += 0.4
        else:
            factors_failed.append('password')

        # Factor 2: TOTP (weight: 0.3)
        if totp_token and totp_secret:
            totp_ok = self.verify_totp(totp_secret, totp_token)
            if totp_ok:
                factors_passed.append('totp')
                trust_score += 0.3
            else:
                factors_failed.append('totp')
        else:
            # TOTP not configured - partial credit
            trust_score += 0.1

        # Factor 3: Keystroke Dynamics ML (weight: 0.3)
        if keystroke_score is not None:
            if keystroke_score >= 0.7:
                factors_passed.append('keystroke_dynamics')
                trust_score += 0.3
            elif keystroke_score >= 0.4:
                factors_passed.append('keystroke_dynamics (partial)')
                trust_score += 0.15
            else:
                factors_failed.append('keystroke_dynamics')

        # Risk assessment
        risk = self.calculate_risk_score(user_id, ip_address) if user_id else {
            'risk_score': 0, 'risk_level': 'low', 'factors': []
        }

        # Reduce trust score based on risk
        trust_score = max(0, trust_score - risk['risk_score'] * 0.2)

        authenticated = password_ok and trust_score >= 0.4

        # Record attempt
        if user_id:
            self.record_login_attempt(
                user_id, authenticated, ip_address,
                keystroke_score or 0.0
            )

        return {
            'authenticated': authenticated,
            'trust_score': round(trust_score, 2),
            'factors_passed': factors_passed,
            'factors_failed': factors_failed,
            'risk_assessment': risk,
            'timestamp': datetime.utcnow().isoformat()
        }
