"""Create a test user for messaging demo."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db, cipher, authenticator
from models.database import User

with app.app_context():
    # Check if test user already exists
    if User.query.filter_by(username='alice_demo').first():
        print('Test user "alice_demo" already exists!')
    else:
        password_hash = authenticator.hash_password('DemoPass@2026')
        private_key, public_key = cipher.generate_rsa_keypair()
        totp_secret = authenticator.generate_totp_secret()

        user = User(
            username='alice_demo',
            email='alice@demo.com',
            password_hash=password_hash,
            public_key=public_key.decode('utf-8'),
            private_key=private_key.decode('utf-8'),
            totp_secret=totp_secret,
            totp_enabled=False
        )
        db.session.add(user)
        db.session.commit()
        print(f'Created test user "alice_demo" (id={user.id})')
        print(f'Password: DemoPass@2026')

    # Show all users
    print('\nAll users:')
    for u in User.query.all():
        print(f'  - {u.username} (id={u.id}, email={u.email})')
